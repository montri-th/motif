# Landometer + ijji Motif — Handoff Kit

Version 1.2.1 · packaged 10 September 2026 · for use in any Landometer project and in outside design work by authorized operators.

Everything in this folder is the exact byte set from the owner-approved Motif Library release 1.2.1, plus one addition made here: a measured quiet-placement contrast ladder. Nothing in the assets was edited.

---

## 1 · สิ่งที่อยู่ในกล่อง

| Path | สิ่งที่เป็น |
| --- | --- |
| `Motif Handoff Kit.dc.html` | หน้าเดียวสำหรับเลือก asset, ทดสอบ contrast บน carrier จริง, และคัดลอก snippet |
| `assets/motif-library.json` | machine manifest — **แหล่งความจริงเดียว** ของ assetId, path, sha256, allowedJob, allowedFormat |
| `assets/landometer/` | runtime v3 (css+js) + final-state SVG 12 ไฟล์ (6 kinds × full/quiet) |
| `assets/ijji/logo-sting/` | animated identity r3 — runtime เดียว + layer PNG ทั้งชุด + still 2 ไฟล์ |
| `assets/ijji/svg/` | pending-state motifs 3 ตัว × 6 surfaces = 18 ไฟล์ |
| `assets/identity/logo/` | official identity renditions (color / white / cream / gray / mono / outline / lockup) |
| `assets/fonts/` | ฟอนต์ 5 ตระกูลพร้อม OFL — ใช้ได้แบบ offline |
| `assets/tokens/color-srgb-05.production.css` | ชุดสี production ของ LDS 0.9.1 |
| `docs/usage-guide.md` · `docs/ai-sync.md` | คู่มือฉบับเจ้าของ + retrieval contract สำหรับ AI/agent |
| `governance/` | owner approval, SHA256SUMS, build card, source ledger, decision records |
| `governance/quiet-contrast-evidence.json` | **ใหม่** — ค่า contrast ที่วัดจริงจากไบต์ของไฟล์ในกล่องนี้ |
| `motif-quiet-fallback.json` | **ใหม่** — quiet fallback ladder แบบ machine-readable |

## 2 · ขอบเขตที่ต้องพูดให้ตรง

- Motif คือการ **จัดจังหวะ** ไม่ใช่ identity, ไม่ใช่ข้อมูล, ไม่ใช่หลักฐาน, ไม่ใช่ score, confidence, completion หรือ product claim
- Landometer layer ต้อง **product-neutral** ครอบ Land · Location · Living; ijji อยู่ในขอบเขต ijji เท่านั้น การย้ายข้ามชั้นต้องมี owner decision + asset record ใหม่
- Release 1.2.1 เป็น **artifact overlay** ไม่ได้แก้ LDS 0.9.1, ijji DS 0.5.0 หรือ Add-on 0.5.3 ย้อนหลัง
- เปิดดู/ดาวน์โหลดได้ทุกคน แต่ **การนำไปใช้ต่อสงวนสำหรับทีม ผู้ร่วมงาน และ AI/agent workflow ที่เจ้าของอนุญาต** — ไม่ใช่ open-source license (`LICENSE.md`)
- ห้าม redraw · recolor · crop geometry · distort · trace จาก screenshot หรือความจำ

## 3 · เลือกด้วยสี่คำตอบ

| | คำถาม | ค่าที่รับได้ |
| --- | --- | --- |
| 01 | **LAYER** ของใคร | `shared_landometer` · `ijji_product_specific` |
| 02 | **JOB** ช่วยอะไร | orientation · spatial transition · layering/divider · action closure · cultural closure/handoff · animated brand opening · real pending state |
| 03 | **FORMAT** ส่งที่ไหน | `web_public` · `deck_16x9` · `social_square_1080` · `document_pdf` · `video_owner_extension` |
| 04 | **MODE** ขยับอย่างไร | `static` (baseline) · `finite_once` · `finite_once_logo_sting` · `state_bound_only` |

Baseline ของทุก record คือ `static` — motion เป็น extension ที่ใช้ได้เฉพาะ `web_public` และต้องเลือก extension ที่ `familyId` ตรงกันเท่านั้น

| Family | งาน | Motion จริง |
| --- | --- | --- |
| `landometer.motif.v3` | shared framing 6 kinds × full/quiet | `finite_once` — เล่นครั้งเดียวแล้วค้าง final |
| `ijji.logo-sting.r3` | ijji animated identity (9.0 s full · 6.4 s mark-only) | `finite_once_logo_sting` — เล่นเมื่อเห็น ≥14% แล้วค้าง final |
| `ijji.four-beat.selected-3.r3` | pending state จริง: graph-b 4.4 s · rings-c 5 s · rotate-b 4 s | `state_bound_only` — หยุดเมื่อ success / failure / cancel / timeout |

หน้า library ต้นทางเล่นซ้ำอัตโนมัติ — **นั่นเป็น inspection aid ห้ามคัดลอกพฤติกรรมนั้นเข้า production**

## 4 · ขนาดขั้นต่ำและ timing ที่ห้ามเดา

- Landometer motif: 160 px (full) / 96 px (quiet)
- Landometer logo assembly: full จบที่ 2870 ms · quiet จบที่ 3360 ms — **ห้ามใช้ cutoff 2050 ms ของ release เก่า** และห้ามใส่ host override `--lm-wedge:#0195CB`; v3 ใช้ wedge จาก token ซึ่ง browser แสดงเป็น `#1F87CE`
- ijji identity: full+tagline ≥ 320 px · mark-only ≥ 160 px (โปร่งใส ต้องอยู่บน Brand Blue หรือ Dark)
- ijji pending: graph-b ≥ 72 px · rings-c ≥ 40 px · rotate-b ≥ 24 px

## 5 · Quiet placement + contrast fallback

> กติกาแม่: **contrast ที่ไม่พอ ไม่เคยแก้ที่ลาย — แก้ที่พื้น** ลายทุกชิ้นห้าม recolor ดังนั้นทางออกคือเปลี่ยน carrier, เปลี่ยน record, เปลี่ยนขนาด หรือไม่ใช้ลายเลย

**สิ่งที่วัดได้จากไบต์จริง:** quiet variant ของ Landometer ทุกตัววาดด้วยหมึกสีเดียวคือ `--energy-sky #59D2FE` ค่าที่วัดได้คือ

- บนพื้นสว่างทุกตัวของ LDS: **1.23–1.69 : 1** → ทำได้แค่ตกแต่ง ห้ามแบกความหมาย
- บนพื้นลึก: Brand Blue 5.19 · Measure Deep 3.19–3.49 · Ground Current 3.29–4.59 · dark surfaces **7.44–10.23 : 1** → รับงานที่สื่อความหมายได้
- ที่ alpha ตามที่ไฟล์เขียนไว้ (.56) มีแค่ชุด dark ที่ยังผ่าน 3:1 (3.42–4.05)

**เกณฑ์ตัดสิน** — วัดชิ้นส่วนที่เข้มที่สุดของ asset ทับบนสี carrier จริง (gradient วัดที่ stop แย่ที่สุด)

| ค่า | คำตัดสิน |
| --- | --- |
| ≥ 3.0 : 1 | รับงานที่สื่อความหมายได้ (WCAG 1.4.11) |
| 1.3 – 2.99 : 1 | ตกแต่งได้ ห้ามแบกความหมาย และต้องต่ำกว่า contrast ของตัวอักษรข้างๆ |
| < 1.3 : 1 | มองไม่เห็น — เปลี่ยน carrier หรือถอดออก |

### บันไดห้าขั้น

1. **L1 · วัดใหม่ ไม่ใช่ย้อมใหม่** — วัดที่ขนาดส่งจริงบนพื้นจริง ถ้าลายเป็น decorative (`alt=""` / `aria-hidden`) แล้วตกในช่วง 1.3–3.0 นั่นคือผลที่ตั้งใจ ส่งได้
2. **L2 · เปลี่ยนพื้น ไม่เปลี่ยนลาย** — ย้ายไปวางบน carrier อื่นที่ DS อนุญาต พื้นสว่างจางเกิน → ชุดพื้นลึก; พื้นลึกจางเกิน → ชุดพื้นสว่าง **ห้ามใส่แผ่นรองสีขาว ห้ามคลุม scrim ทับ gradient ที่ governed ห้ามสร้างสีใหม่**
3. **L3 · เปลี่ยน record ไม่เปลี่ยนสี** — การ *เลือกไฟล์อื่น* ทำได้ การ *ย้อมสี* ทำไม่ได้
   - ijji four-beat มี 6 surface ต่อหนึ่ง motif: พื้นสว่างใช้ `transparent-ink` (`#182327`, 11.4–15.6:1) · พื้นลึกใช้ `transparent-mint` (`#0AD69C`, 3.0–9.4:1) · พื้นที่คุมไม่ได้ใช้ boxed variant ที่ระบุพื้นนั้นตรงๆ
   - Landometer สลับ variant: quiet บนพื้นที่ลายเยอะ/ภาพถ่าย/atmosphere · full บนพื้นสว่างเรียบ
   - **ห้ามวาง full variant บนแผง Brand Blue** — ลาย full มี `#1D4497` เป็นฐาน วัดได้ 1.00:1 คือหายไปทั้งชิ้น
4. **L4 · เปลี่ยนการปรากฏ ไม่เปลี่ยนพาเลตต์** — ขยายเข้าหา 1.5× ของขนาดขั้นต่ำ, ย้ายลายออกจากคอลัมน์ข้อความไปอยู่ track ของตัวเอง, หรือเพิ่มพื้นที่ว่าง 2 ขั้น
5. **L5 · เอาออก** — ให้ข้อความ, TrustBadge, DecisionCard หรือ component จริงเป็นผู้บอกความหมาย **ทดสอบ: ลบลายออกแล้วความจริงบนหน้าต้องไม่เปลี่ยน**

### Carrier ที่เลือกแทนได้ (สีอื่นใน DS ที่ยัง quiet)

พื้นสว่าง — `--surface-card #FCFCFA` 1.69 · `--surface-canvas #F6F7F3` 1.62 · `--brand-beige #F2F1DF` 1.53 · `--surface-alt #EEF1EE` 1.53 · `--semantic-info-fill #E8EEF0` 1.48 · `--surface-soft #E5E9E6` 1.42 · `--surface-blue-tint #E2E9ED` 1.42 · Ground Mist 1.23–1.31

พื้นลึก — dark canvas `#11191D` 10.23 · overlay glass 10.14 · dark alt `#172126` 9.42 · dark card `#20292D` 8.52 · dark blue-tint `#18333E` 7.63 · dark raised `#293337` 7.44 · `--brand-blue #1D4497` 5.19 · Ground Current 3.29–4.59 · Measure Deep 3.19–3.49

**ไม่ใช่ carrier:** Cultivate Glow / Mist (พื้นอุ่นทำให้หมึกฟ้าจางที่สุดและตีกับ energy ink ของลายเอง) · Diversity Spectrum (จำกัดหนึ่งครั้งต่อเส้นทางยาว ห้ามใช้เป็นพื้นรองลาย) · `product.*` gradient (ใช้ในผลิตภัณฑ์เจ้าของเท่านั้น) · ภาพถ่าย (ไม่มีค่าเดียวที่วัดได้ — ใช้ boxed variant แทน)

### Logo — เลือก rendition ไม่ใช่เลือกสี

โลโก้ไม่วางบนแผ่นรองของตัวเอง ถ้า contrast ไม่พอให้เปลี่ยนพื้นรอบ หรือเปลี่ยน rendition

| Rendition | หมึกที่วัดได้ | ใช้บน |
| --- | --- | --- |
| `landometer-symbol-color` | `#1D4497` | พื้นสว่างเท่านั้น (canvas 8.39 · beige 7.92) — บน Brand Blue 1.00 และ dark 1.97 คือใช้ไม่ได้ |
| `-white` · `-mono` · `-outline-white` | `#FFFFFF` | พื้นลึกเท่านั้น (Brand Blue 9.03 · dark 12.94–17.79) — พื้นสว่าง 1.06–1.14 |
| `-cream` · `-outline-cream` | `#EFEFD0` | พื้นลึกเท่านั้น (Brand Blue 7.71) — **บน `--brand-beige` วัดได้ 1.03 : 1** ไฟล์ยังเป็น cream ยุค v0.6.2 การ re-export ที่ `#F2F1DF` เป็น pending approval ของเจ้าของ identity **ห้ามย้อมไฟล์เอง** |
| `-gray` | `#757575` | **quiet universal** — rendition เดียวที่ผ่าน 3:1 ทั้งพื้นสว่าง (4.28) และพื้นมืด (3.86) ใช้เมื่อคุมพื้นไม่ได้หรือต้องรอด theme switch — แต่ตกบน Brand Blue (1.96) และ Measure Deep / Ground Current |

ijji mark-only ยังคงกติกาเดิม: still โปร่งใส วางได้บน Brand Blue `#1D4497` หรือ Dark `#11191D` เท่านั้น ถ้าไม่มีทั้งสองอย่าง ให้ใช้ full+tagline ที่พาพื้น Brand Blue มาเองที่ ≥ 320 px

> สถานะของบันไดนี้: **derived guidance — ยังไม่มี owner decision** สร้างจากไบต์จริงของไฟล์ในกล่องนี้ + ค่า token ของ LDS 0.9.1 + กติกาเดิมที่ว่า "แก้ที่พื้น ไม่แก้ที่มาร์ก" ใช้เป็นข้อเสนอได้ แต่ยังไม่ใช่ normative จนเจ้าของบันทึกคำตัดสิน

## 6 · Snippet

Web · Landometer finite once (fallback อยู่ใน source HTML)

```html
<link rel="stylesheet" href="assets/landometer/landometer-motifs.css">
<script src="assets/landometer/landometer-motifs.js" defer></script>

<lm-motif kind="dial"></lm-motif>
<lm-motif kind="rings" quiet></lm-motif>
<lm-motif kind="logo" ink="blue"></lm-motif>
```

Static ทุก format (deck / PDF / social / email / no-JS)

```html
<img src="assets/landometer/svg/rings-quiet.svg" alt="" aria-hidden="true"
     style="width:min(100%,320px)">
```

ijji pending state — ต้องมีข้อความสถานะที่มองเห็นและปุ่มยกเลิกที่ทำงานจริง

```html
<div style="display:flex;align-items:center;gap:12px">
  <img src="assets/ijji/svg/ijji-rotate-b-transparent-ink.svg" alt="" aria-hidden="true"
       style="width:40px;height:40px">
  <p style="margin:0">กำลังรวบรวมบริบทรอบพื้นที่ · 4 วินาที</p>
  <button type="button">ยกเลิก</button>
</div>
```

## 7 · Agent brief

```
ใช้ไฟล์จาก assets/motif-library.json เท่านั้น

งาน: [ระบุสิ่งที่จะสร้าง]
familyId: [landometer.motif.v3 | ijji.logo-sting.r3 | ijji.four-beat.selected-3.r3]
productScope: [shared_landometer | ijji_product_specific]
assetId / allowedJob / allowedFormat / variant / surface: [คัดลอกจาก record เดียวกัน]
motionMode: static [หรือ extension ที่ familyId ตรงกัน + runtimeAssetIds + lifecycle]
path + sha256 + staticFallback + approvalRef: [คัดลอกจาก record เดียวกัน]

hostSurfaceToken: [token ของพื้นที่ลายวางอยู่จริง]
hostSurfaceHex: [ค่า hex ที่ resolve แล้ว หรือ stop ที่แย่ที่สุดของ gradient]
measuredContrast: [ratio ที่คำนวณ ไม่ใช่ประมาณ]
contrastVerdict: [meaningCapable | decorativeOnly | invisible]
quietFallbackRung: [none | L2 | L3 | L4 | L5]   fallbackAssetId: [ถ้าเปลี่ยน record]

ห้าม redraw / recolor / crop / distort / trace; ห้ามใช้ motif แทน identity, data, evidence หรือ claim
ก่อนส่ง: ยืนยัน familyId + assetId + path + sha256 จาก record เดียวกัน, ใส่ static/reduced-motion fallback,
ตรวจ output ที่ส่งจริง แล้วรายงานทุก gate ที่ยังไม่ได้ตรวจ
```

## 8 · เช็กก่อนส่ง

**Boundary** — ชั้นถูก · ไม่เหมารวมอุตสาหกรรมหรือเมือง · ข้ามผลิตภัณฑ์ใช้ schema/release เดียวกันหรือบอก incompatibility
**Meaning** — ลายไม่แทน identity · สถานะจริงมีข้อความที่มองเห็น · ลบลายแล้วความจริงไม่เปลี่ยน
**Asset** — path, revision, SHA-256 ตรง manifest · ไม่ redraw/recolor/crop/stretch · ใช้ selected ไม่ใช่ exploration
**Contrast** — วัดแล้วบันทึก verdict · ถ้าไม่ผ่านให้ระบุขั้นบันไดที่ใช้แก้
**Access** — decorative ใช้ `alt=""` / `aria-hidden` · meaningful มี text alternative · pending มีข้อความ เวลา และ cancel
**Fallback** — no-JS และ reduced motion เห็น final static · print/email ใช้ภาพนิ่ง · motion ไม่ทำ layout shift และไม่บัง action
**Output** — ทดสอบ viewport และไฟล์ export จริง · social claim จำกัดที่ 1080×1080 · ratio อื่นเป็น owner extension

## 9 · ที่มา

- Canonical: <https://montri-th.github.io/motif/> · repo `montri-th/motif@main` · Drive release 1.2.1
- Design authority: LDS 0.9.1 / 0.9.1-r8 / v0.9.1-mp7 · owner approval 6 September 2026 (`governance/owner-approval.json`)
- Runtime hashes: Landometer CSS `7cc2deb4…12e` · JS `3a5caef7…af2` · ijji identity runtime `1a1d1bc2…433e`
- Checksum ของทุกไฟล์: `governance/SHA256SUMS.txt`

**Gate ที่ยังไม่ได้ตรวจในกล่องนี้:** ยังไม่ได้ re-hash ไบต์ที่คัดลอกมาเทียบ `SHA256SUMS.txt` ในเครื่องนี้ · quiet fallback ladder ยังไม่มี owner decision · cream rendition ยังรอ re-export ที่ `#F2F1DF`
