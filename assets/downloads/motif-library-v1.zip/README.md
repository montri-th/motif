# Landometer Motif Library

A bilingual learning site and exact-byte asset library for Landometer shared motifs and ijji product-specific motifs.

Artifact release: **1.1.1** · 5 September 2026

Live target: <https://montri-th.github.io/motif/>

## Start here

- Browse the Thai guide at `/` or the English guide at `/en/`.
- Read [`assets/motif-library.json`](assets/motif-library.json) before automated use.
- Read [`docs/usage-guide.md`](docs/usage-guide.md) for implementation and handoff guidance.
- Read [`docs/ai-sync.md`](docs/ai-sync.md) or [`CLAUDE.md`](CLAUDE.md) before Claude/ChatGPT retrieval from the shared Drive mirror.
- Verify downloaded bytes with [`governance/SHA256SUMS.txt`](governance/SHA256SUMS.txt). Each ZIP contains a package-specific copy that hashes every other file inside that ZIP.
- Read [`governance/owner-approval.json`](governance/owner-approval.json) and [`LICENSE.md`](LICENSE.md) for the approval and rights boundary.

## The two brand layers

| Layer | Use | Boundary |
| --- | --- | --- |
| Landometer shared | Orientation, transition, and closure across product-neutral Land, Location, and Living communication | A motif is framing—not identity, data, evidence, or a measured state |
| ijji product-specific | Selected `graph-b`, `rings-c`, and `rotate-b` assets inside ijji | Do not generalize ijji examples or assets into Landometer or another product |

Both families are owner-approved artifact overlays dated 5 September 2026. They are not retroactively part of the immutable LDS 0.9.1 or ijji DS/Add-on 0.5.0/0.5.3 releases.

## Local preview

The site has no dependency install or build step. Serve the repository root with any static HTTP server, for example:

```sh
python3 -m http.server 4173
```

Then open <http://localhost:4173/>. Core content and static motif previews remain available without JavaScript. JavaScript adds search, filters, an owner-selected full + quiet inspection showcase, bounded ijji state previews, theme switching, copy actions, and local PNG export.

## Showcase inspection versus production motion

Since release 1.1.0, opening a Landometer Preview dialog reveals the full and quiet variants side by side, starts both immediately, and replays them together every 3000 ms while the dialog stays open and visible. The viewer can pause auto-replay or replay immediately. Reduced-motion users receive both stable final states without the replay timer.

This loop is a component-local instructional aid for this library—not a new production motion contract. The governed runtime bytes, implementation snippets, and machine manifest remain `finite_once`; the hero remains one-shot and asset-card thumbnails remain static. ijji is excluded and remains `state_bound_only`. The exact decision and stopping rules are recorded in [`governance/showcase-motion-decision.json`](governance/showcase-motion-decision.json).

Release 1.1.1 changes only the Landometer `logo-full` assembly geometry and the minimal CSS declaration it requires. Controlled radial and 0.25° angular overlaps close the visible anti-alias gaps in the held final frame. `logo-quiet`, the other five motif kinds, ijji, and the production motion lifecycles are unchanged. The scoped decision and claim boundary are recorded in [`governance/logo-full-geometry-decision.json`](governance/logo-full-geometry-decision.json).

## Shared Google Drive mirror

The complete release is mirrored in the [Landometer Motif Library Drive folder](https://drive.google.com/drive/folders/1JXbcZovWZsOFtA9MykVeLhB_JzHg_nPh) as immutable versioned assets, expanded SVG/CSS/JS files, source archives, manifests, checksums, and ready-to-use ZIPs. Claude and ChatGPT must resolve `release-index.json` and verify the selected release checksum at the start of each task. This is explicit synchronization through one source of truth, not an automatic background sync.

## File map

```text
index.html                         Thai route
en/index.html                      English route
site.css / site.js                 site presentation and progressive enhancement
assets/landometer/                 exact runtime + generated final-state SVGs
assets/ijji/                       exact selected assets; explorations excluded
assets/motif-library.json          machine-readable asset and boundary contract
assets/downloads/                  ready-to-share kits
docs/usage-guide.md                manual + AI/agent workflow
docs/ai-sync.md / CLAUDE.md        shared Drive retrieval and update contract
governance/                        owner approval, source ledger, Build Card, QA, hashes
llms.txt                           bounded machine-discovery entrypoint
```

## Deterministic maintenance

Run these scripts after changing source assets:

```sh
node scripts/build-static-assets.mjs
node scripts/build-manifest.mjs
shasum -a 256 assets/motif-library.json
NODE_PATH=/path/to/node_modules node scripts/build-downloads.mjs
node scripts/build-checksums.mjs
node scripts/verify-site.mjs
```

After `build-manifest.mjs`, inspect the contract diff and confirm that the change is within current owner authority. Then bind the reviewed digest to `assetManifestSha256` in `governance/owner-approval.json` before rebuilding downloads and repository checksums. Never re-bind a changed manifest mechanically when its scope lacks owner approval.

The release runtime is a scoped derivative: the finite-once base from `Landometer Brand Motifs Assets and Prompt.zip` plus only the corroborated logo-full anti-seam geometry from `Landometer Brand Motifs Asset and Prompt.zip` / `Landometer Brand Motifs HTML2.zip`. The new source's replay/loop APIs are intentionally excluded. Exact source and artifact hashes are recorded in `governance/source-ledger.json`.

## ภาษาไทยแบบสั้น

คลังนี้ช่วยให้ทีมเลือก motif ตาม brand layer, งาน, channel และ motion mode จากไฟล์จริงที่มี version/hash ชัดเจน ห้ามใช้ motif เป็นโลโก้ ข้อมูล หลักฐาน หรือ claim และห้ามนำ ijji ไปเหมารวมเป็น Landometer ทุกงานควรตรวจ static fallback, reduced motion, accessibility และไฟล์ส่งจริงก่อนเผยแพร่

ตั้งแต่ release 1.1.0 หน้าต่าง Preview ของ Landometer จะแสดง full + quiet พร้อมกันและวนซ้ำทุก 3 วินาทีเพื่อให้ตรวจ animation ได้ง่าย พฤติกรรมนี้เป็นโหมดสาธิตเฉพาะคลัง ไม่ใช่ค่า production: runtime, ตัวอย่างโค้ด และ manifest ยังใช้ `finite_once`; hero ยังเล่นครั้งเดียว, card ยังเป็นภาพนิ่ง และ ijji ยังคง `state_bound_only` ส่วน release 1.1.1 แก้เฉพาะปลายทางของ `logo-full` ให้ประกอบครบ ไม่มีรอยแหว่ง โดยไม่เปลี่ยน quiet หรือ motif อื่น
